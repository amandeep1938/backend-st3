jQuery(function ($) {
    $("#phone").mask("+38(099)999-99-99");
});

